package collection2;

public class Main {

	public static void main(String[] args) {
		// Example 타입 변수를 생성해주신 다음
		// 콘솔에 해당 변수를 찍어보세요.
		Example e = new Example();
		System.out.println(e);
	}
}
